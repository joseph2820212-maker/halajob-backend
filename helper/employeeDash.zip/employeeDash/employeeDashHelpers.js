import mongoose from "mongoose";
import {
  EmployeeModel,
  UserModel,
  jobsModel,
  UserApplyingJobModel,
  UserSavedJobModel,
  UserShowJobModel,
  UserOutSideApplyingJobModel,
  UserReviewJobModel,
  UserRatingJobModel,
  CompanyModel,
} from "../../models/index.js";

export const isValidObjectId = (id) => mongoose.Types.ObjectId.isValid(id);

export const getAuthUserId = (req) => {
  return req.authData?._id || req.user?._id || req.userId || req.auth?._id;
};

export const success = (res, data = null, message = "success", status = 200, meta = undefined) => {
  const payload = { success: true, message, data };
  if (meta) payload.meta = meta;
  return res.status(status).json(payload);
};

export const fail = (res, message = "Bad request", status = 400, errors = undefined) => {
  const payload = { success: false, message };
  if (errors) payload.errors = errors;
  return res.status(status).json(payload);
};

export const pickLanguage = (req) => {
  const lan = req.headers?.lan || req.headers?.language || req.query?.lan || "en";
  return lan === "ar" ? "ar" : "en";
};

export const localized = (doc, req, fallback = "") => {
  if (!doc) return fallback;
  const lan = pickLanguage(req);
  return lan === "ar"
    ? doc.title_ar || doc.name_ar || doc.title_en || doc.name || fallback
    : doc.title_en || doc.name_en || doc.title_ar || doc.name || fallback;
};

export const getEmployeeOrFail = async (req, res, options = {}) => {
  const userId = getAuthUserId(req);

  if (!userId || !isValidObjectId(userId)) {
    fail(res, "Invalid authenticated user id", 401);
    return null;
  }

  const query = EmployeeModel.findOne({ user_id: userId });

  if (options.populate !== false) {
    query
      .populate("user_id", "first_name mid_name last_name image email gender phone phone_e164 phone_country phone_code phone_national lan status")
      .populate("role_id", "name title_ar title_en")
      .populate("job_types", "name title_ar title_en keyword option")
      .populate("languages.language_id", "name title_ar title_en");
  }

  const employee = await query;

  if (!employee) {
    fail(res, "Employee profile not found for this user", 404);
    return null;
  }

  return employee;
};

export const getEmployeePlain = async (req, res) => {
  const employee = await getEmployeeOrFail(req, res, { populate: false });
  return employee;
};

export const getEmployeeUserIdOrFail = async (req, res) => {
  const employee = await getEmployeePlain(req, res);
  if (!employee) return null;
  return { employee, userId: employee.user_id };
};

export const normalizeArrayPayload = (body, fieldName) => {
  if (Array.isArray(body)) return body;
  if (fieldName && Array.isArray(body?.[fieldName])) return body[fieldName];
  if (fieldName && body?.[fieldName] !== undefined) return [body[fieldName]];
  return [body].filter(Boolean);
};

export const toObjectIdArray = (items = []) => {
  return items.filter(Boolean).filter(isValidObjectId).map((id) => new mongoose.Types.ObjectId(id));
};

export const buildPagination = (req) => {
  const page = Math.max(parseInt(req.query.page || "1", 10), 1);
  const limit = Math.min(Math.max(parseInt(req.query.limit || "20", 10), 1), 100);
  const skip = (page - 1) * limit;
  return { page, limit, skip };
};

export const paginate = async (model, filter, req, options = {}) => {
  const { page, limit, skip } = buildPagination(req);
  const sort = options.sort || { createdAt: -1, _id: -1 };

  const [items, total] = await Promise.all([
    model.find(filter).sort(sort).skip(skip).limit(limit).populate(options.populate || []),
    model.countDocuments(filter),
  ]);

  return {
    items,
    meta: {
      page,
      limit,
      total,
      pages: Math.ceil(total / limit),
    },
  };
};

export const publicJobPopulate = [
  { path: "company_id", select: "company_name image company_country company_address company_website company_size company_type" },
  { path: "job_name_id", select: "title_ar title_en sector_ar sector_en subSector_ar subSector_en" },
  { path: "job_type_id", select: "name title_ar title_en" },
  { path: "job_time_id", select: "name title_ar title_en max_day" },
  { path: "job_salary_id", select: "name title_ar title_en" },
  { path: "currency_id", select: "name title_ar title_en code symbol" },
  { path: "languages.language_id", select: "name title_ar title_en" },
];

export const getEmployeeStats = async (userId) => {
  const [
    appliedCount,
    waitingCount,
    acceptedCount,
    rejectedCount,
    interviewCount,
    savedCount,
    viewedCount,
    outsideApplyCount,
    reviewsCount,
    ratingsCount,
  ] = await Promise.all([
    UserApplyingJobModel.countDocuments({ user_id: userId }),
    UserApplyingJobModel.countDocuments({ user_id: userId, status: "waiting" }),
    UserApplyingJobModel.countDocuments({ user_id: userId, status: "accepted" }),
    UserApplyingJobModel.countDocuments({ user_id: userId, status: "rejected" }),
    UserApplyingJobModel.countDocuments({ user_id: userId, is_send_interview: true }),
    UserSavedJobModel.countDocuments({ user_id: userId }),
    UserShowJobModel.countDocuments({ user_id: userId }),
    UserOutSideApplyingJobModel.countDocuments({ user_id: userId }),
    UserReviewJobModel.countDocuments({ user_id: userId }),
    UserRatingJobModel.countDocuments({ user_id: userId }),
  ]);

  return {
    applications: {
      total: appliedCount,
      waiting: waitingCount,
      accepted: acceptedCount,
      rejected: rejectedCount,
      interviews: interviewCount,
      outside: outsideApplyCount,
    },
    jobs: {
      saved: savedCount,
      viewed: viewedCount,
      reviews: reviewsCount,
      ratings: ratingsCount,
    },
  };
};

export const calculateProfileCompletion = (employee) => {
  const checks = [
    !!employee.about_me,
    !!employee.latest_work_experience?.company_name,
    !!employee.latest_work_experience?.position,
    Array.isArray(employee.experience) && employee.experience.length > 0,
    Array.isArray(employee.education) && employee.education.length > 0,
    Array.isArray(employee.skills) && employee.skills.length > 0,
    Array.isArray(employee.languages) && employee.languages.length > 0,
    Array.isArray(employee.job_names) && employee.job_names.length > 0,
    Array.isArray(employee.job_types) && employee.job_types.length > 0,
    Array.isArray(employee.min_salary) && employee.min_salary.length > 0,
    !!employee.work_location,
    Array.isArray(employee.cvs) && employee.cvs.length > 0,
  ];

  const completed = checks.filter(Boolean).length;
  return {
    completed,
    total: checks.length,
    percent: Math.round((completed / checks.length) * 100),
  };
};

export const buildRecommendedJobFilter = (employee) => {
  const or = [];

  if (employee.job_names?.length) {
    or.push({ job_name: { $in: employee.job_names.map((v) => new RegExp(v, "i")) } });
    or.push({ job_keywords: { $in: employee.job_names } });
  }

  if (employee.skills?.length) {
    const skills = employee.skills.map((skill) => skill.title).filter(Boolean);
    if (skills.length) or.push({ job_keywords: { $in: skills } });
  }

  if (employee.job_types?.length) {
    or.push({ job_type_id: { $in: employee.job_types } });
  }

  const filter = { status: true, is_accepted: true };
  if (or.length) filter.$or = or;
  return filter;
};

export const getCompanyIdsFromEmployeeActivity = async (userId) => {
  const [applied, saved, shown] = await Promise.all([
    UserApplyingJobModel.find({ user_id: userId }).select("job_id"),
    UserSavedJobModel.find({ user_id: userId }).select("job_id"),
    UserShowJobModel.find({ user_id: userId }).select("job_id"),
  ]);

  const jobIds = [...applied, ...saved, ...shown].map((x) => x.job_id).filter(Boolean);
  if (!jobIds.length) return [];

  const jobs = await jobsModel.find({ _id: { $in: jobIds } }).select("company_id");
  return [...new Set(jobs.map((j) => String(j.company_id)).filter(Boolean))];
};
