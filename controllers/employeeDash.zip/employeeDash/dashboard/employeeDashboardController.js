import {
  jobsModel,
  UserApplyingJobModel,
  UserSavedJobModel,
} from "../../../models/index.js";
import {
  getEmployeeUserIdOrFail,
  success,
  publicJobPopulate,
  getEmployeeStats,
  calculateProfileCompletion,
  buildRecommendedJobFilter,
} from "../../../helper/employeeDash/employeeDashHelpers.js";

export const getEmployeeDashboard = async (req, res, next) => {
  try {
    const employeeData = await getEmployeeUserIdOrFail(req, res);
    if (!employeeData) return;

    const { employee, userId } = employeeData;

    const stats = await getEmployeeStats(userId);
    const completion = calculateProfileCompletion(employee);

    const [latestApplications, savedJobs, recommendedJobs, latestJobs] = await Promise.all([
      UserApplyingJobModel.find({ user_id: userId })
        .sort({ createdAt: -1 })
        .limit(5)
        .populate([{ path: "job_id", populate: publicJobPopulate }]),
      UserSavedJobModel.find({ user_id: userId })
        .sort({ createdAt: -1 })
        .limit(5)
        .populate([{ path: "job_id", populate: publicJobPopulate }]),
      jobsModel.find(buildRecommendedJobFilter(employee))
        .sort({ createdAt: -1 })
        .limit(8)
        .populate(publicJobPopulate),
      jobsModel.find({ status: true, is_accepted: true })
        .sort({ createdAt: -1 })
        .limit(8)
        .populate(publicJobPopulate),
    ]);

    return success(res, {
      profile: {
        employee,
        completion,
      },
      stats,
      latest_applications: latestApplications,
      saved_jobs: savedJobs,
      recommended_jobs: recommendedJobs,
      latest_jobs: latestJobs,
    }, "employee_dashboard");
  } catch (error) {
    next(error);
  }
};

export default {
  getEmployeeDashboard,
};
