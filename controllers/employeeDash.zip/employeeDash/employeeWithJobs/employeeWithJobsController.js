import mongoose from "mongoose";
import {
  jobsModel,
  UserApplyingJobModel,
  UserSavedJobModel,
  UserShowJobModel,
  UserOutSideApplyingJobModel,
  UserReviewJobModel,
  UserRatingJobModel,
} from "../../../models/index.js";
import {
  getEmployeeUserIdOrFail,
  success,
  fail,
  paginate,
  publicJobPopulate,
  buildRecommendedJobFilter,
  isValidObjectId,
} from "../../../helper/employeeDash/employeeDashHelpers.js";

const publicJobFilter = {
  status: true,
  is_accepted: true,
};

export const browseJobs = async (req, res, next) => {
  try {
    const { search, country, job_type_id, is_remote } = req.query;
    const filter = { ...publicJobFilter };

    if (search) {
      const regex = new RegExp(String(search).trim(), "i");
      filter.$or = [
        { job_name: regex },
        { description: regex },
        { job_keywords: regex },
      ];
    }

    if (country) filter.countries = country;
    if (job_type_id && isValidObjectId(job_type_id)) filter.job_type_id = job_type_id;
    if (is_remote !== undefined) filter.is_remote = String(is_remote) === "true";

    const result = await paginate(jobsModel, filter, req, { populate: publicJobPopulate });
    return success(res, result.items, "jobs_list", 200, result.meta);
  } catch (error) {
    next(error);
  }
};

export const recommendedJobs = async (req, res, next) => {
  try {
    const employeeData = await getEmployeeUserIdOrFail(req, res);
    if (!employeeData) return;

    const filter = buildRecommendedJobFilter(employeeData.employee);
    const result = await paginate(jobsModel, filter, req, { populate: publicJobPopulate });

    return success(res, result.items, "recommended_jobs", 200, result.meta);
  } catch (error) {
    next(error);
  }
};

export const getJobDetails = async (req, res, next) => {
  try {
    const employeeData = await getEmployeeUserIdOrFail(req, res);
    if (!employeeData) return;

    const { jobId } = req.params;
    if (!isValidObjectId(jobId)) return fail(res, "invalid_job_id", 400);

    const job = await jobsModel.findOne({ _id: jobId, ...publicJobFilter }).populate(publicJobPopulate);
    if (!job) return fail(res, "job_not_found", 404);

    await UserShowJobModel.updateOne(
      { user_id: employeeData.userId, job_id: jobId },
      { $setOnInsert: { user_id: employeeData.userId, job_id: jobId } },
      { upsert: true }
    );

    await jobsModel.updateOne({ _id: jobId }, { $inc: { user_show: 1 } });

    const [saved, applied, outsideApplied, rating, review] = await Promise.all([
      UserSavedJobModel.exists({ user_id: employeeData.userId, job_id: jobId }),
      UserApplyingJobModel.findOne({ user_id: employeeData.userId, job_id: jobId }),
      UserOutSideApplyingJobModel.exists({ user_id: employeeData.userId, job_id: jobId }),
      UserRatingJobModel.findOne({ user_id: employeeData.userId, job_id: jobId }),
      UserReviewJobModel.findOne({ user_id: employeeData.userId, job_id: jobId }),
    ]);

    return success(res, {
      job,
      viewer_state: {
        is_saved: !!saved,
        is_applied: !!applied,
        is_outside_applied: !!outsideApplied,
        application_status: applied?.status || null,
        rating: rating?.rating || null,
        review: review?.message || null,
      },
    }, "job_details");
  } catch (error) {
    next(error);
  }
};

export const saveJob = async (req, res, next) => {
  try {
    const employeeData = await getEmployeeUserIdOrFail(req, res);
    if (!employeeData) return;

    const { jobId } = req.params;
    if (!isValidObjectId(jobId)) return fail(res, "invalid_job_id", 400);

    const job = await jobsModel.findOne({ _id: jobId, ...publicJobFilter }).select("_id");
    if (!job) return fail(res, "job_not_found", 404);

    await UserSavedJobModel.updateOne(
      { user_id: employeeData.userId, job_id: jobId },
      { $setOnInsert: { user_id: employeeData.userId, job_id: jobId } },
      { upsert: true }
    );

    await jobsModel.updateOne({ _id: jobId }, { $inc: { user_saved: 1 } });

    return success(res, { job_id: jobId }, "job_saved");
  } catch (error) {
    if (error.code === 11000) return success(res, { job_id: req.params.jobId }, "job_already_saved");
    next(error);
  }
};

export const unsaveJob = async (req, res, next) => {
  try {
    const employeeData = await getEmployeeUserIdOrFail(req, res);
    if (!employeeData) return;

    const { jobId } = req.params;
    if (!isValidObjectId(jobId)) return fail(res, "invalid_job_id", 400);

    const deleted = await UserSavedJobModel.deleteOne({ user_id: employeeData.userId, job_id: jobId });
    if (deleted.deletedCount) {
      await jobsModel.updateOne({ _id: jobId, user_saved: { $gt: 0 } }, { $inc: { user_saved: -1 } });
    }

    return success(res, { job_id: jobId }, "job_unsaved");
  } catch (error) {
    next(error);
  }
};

export const savedJobs = async (req, res, next) => {
  try {
    const employeeData = await getEmployeeUserIdOrFail(req, res);
    if (!employeeData) return;

    const result = await paginate(
      UserSavedJobModel,
      { user_id: employeeData.userId },
      req,
      { populate: [{ path: "job_id", populate: publicJobPopulate }] }
    );

    return success(res, result.items, "saved_jobs", 200, result.meta);
  } catch (error) {
    next(error);
  }
};

export const applyToJob = async (req, res, next) => {
  try {
    const employeeData = await getEmployeeUserIdOrFail(req, res);
    if (!employeeData) return;

    const { jobId } = req.params;
    if (!isValidObjectId(jobId)) return fail(res, "invalid_job_id", 400);

    const job = await jobsModel.findOne({ _id: jobId, ...publicJobFilter });
    if (!job) return fail(res, "job_not_found", 404);

    if (job.is_out_side) {
      await UserOutSideApplyingJobModel.updateOne(
        { user_id: employeeData.userId, job_id: jobId },
        { $setOnInsert: { user_id: employeeData.userId, job_id: jobId } },
        { upsert: true }
      );
      await jobsModel.updateOne({ _id: jobId }, { $inc: { out_side_applying: 1 } });
      return success(res, { out_link: job.out_link }, "outside_job_apply_registered");
    }

    const user = employeeData.employee.user_id;

    const payload = {
      user_id: employeeData.userId,
      job_id: jobId,
      first_name: req.body.first_name || user?.first_name,
      last_name: req.body.last_name || user?.last_name,
      email: req.body.email || user?.email,
      phone_code: req.body.phone_code || user?.phone_code,
      phone_national: req.body.phone_national || user?.phone_national,
      country_id: req.body.country_id,
      answers: req.body.answers || [],
      cv: req.body.cv,
      cover_letter: req.body.cover_letter,
    };

    const requiredFields = ["first_name", "last_name", "email", "phone_code", "phone_national", "country_id"];
    const missing = requiredFields.filter((field) => !payload[field]);
    if (missing.length) return fail(res, "missing_application_fields", 422, missing);

    const application = await UserApplyingJobModel.create(payload);
    await jobsModel.updateOne({ _id: jobId }, { $inc: { user_applying: 1 } });

    return success(res, application, "job_application_created", 201);
  } catch (error) {
    if (error.code === 11000) return fail(res, "already_applied_to_job", 409);
    next(error);
  }
};

export const myApplications = async (req, res, next) => {
  try {
    const employeeData = await getEmployeeUserIdOrFail(req, res);
    if (!employeeData) return;

    const filter = { user_id: employeeData.userId };
    if (req.query.status) filter.status = req.query.status;
    if (req.query.interviews === "true") filter.is_send_interview = true;

    const result = await paginate(UserApplyingJobModel, filter, req, {
      populate: [{ path: "job_id", populate: publicJobPopulate }],
    });

    return success(res, result.items, "my_applications", 200, result.meta);
  } catch (error) {
    next(error);
  }
};

export const myInterviews = async (req, res, next) => {
  try {
    const employeeData = await getEmployeeUserIdOrFail(req, res);
    if (!employeeData) return;

    const result = await paginate(
      UserApplyingJobModel,
      { user_id: employeeData.userId, is_send_interview: true },
      req,
      { populate: [{ path: "job_id", populate: publicJobPopulate }], sort: { send_interview_at: -1, createdAt: -1 } }
    );

    return success(res, result.items, "my_interviews", 200, result.meta);
  } catch (error) {
    next(error);
  }
};

export const rateJob = async (req, res, next) => {
  try {
    const employeeData = await getEmployeeUserIdOrFail(req, res);
    if (!employeeData) return;

    const { jobId } = req.params;
    const rating = Number(req.body.rating);

    if (!isValidObjectId(jobId)) return fail(res, "invalid_job_id", 400);
    if (!Number.isFinite(rating) || rating < 1 || rating > 5) return fail(res, "invalid_rating", 422);

    const result = await UserRatingJobModel.findOneAndUpdate(
      { user_id: employeeData.userId, job_id: jobId },
      { user_id: employeeData.userId, job_id: jobId, rating },
      { upsert: true, new: true, setDefaultsOnInsert: true }
    );

    return success(res, result, "job_rated");
  } catch (error) {
    next(error);
  }
};

export const reviewJob = async (req, res, next) => {
  try {
    const employeeData = await getEmployeeUserIdOrFail(req, res);
    if (!employeeData) return;

    const { jobId } = req.params;
    const message = String(req.body.message || "").trim();

    if (!isValidObjectId(jobId)) return fail(res, "invalid_job_id", 400);
    if (!message) return fail(res, "review_message_required", 422);

    const result = await UserReviewJobModel.findOneAndUpdate(
      { user_id: employeeData.userId, job_id: jobId },
      { user_id: employeeData.userId, job_id: jobId, message },
      { upsert: true, new: true, setDefaultsOnInsert: true }
    );

    return success(res, result, "job_review_saved");
  } catch (error) {
    next(error);
  }
};

export default {
  browseJobs,
  recommendedJobs,
  getJobDetails,
  saveJob,
  unsaveJob,
  savedJobs,
  applyToJob,
  myApplications,
  myInterviews,
  rateJob,
  reviewJob,
};
