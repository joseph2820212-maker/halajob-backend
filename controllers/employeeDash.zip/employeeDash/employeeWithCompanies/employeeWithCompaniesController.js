import {
  CompanyModel,
  jobsModel,
  UserApplyingJobModel,
  UserSavedJobModel,
  UserShowJobModel,
} from "../../../models/index.js";
import {
  getEmployeeUserIdOrFail,
  success,
  fail,
  paginate,
  publicJobPopulate,
  isValidObjectId,
  getCompanyIdsFromEmployeeActivity,
} from "../../../helper/employeeDash/employeeDashHelpers.js";

export const browseCompanies = async (req, res, next) => {
  try {
    const { search, country, type } = req.query;
    const filter = { status: true, accepted: true };

    if (search) {
      const regex = new RegExp(String(search).trim(), "i");
      filter.$or = [
        { company_name: regex },
        { description: regex },
        { company_email: regex },
      ];
    }

    if (country) filter.company_country = country;
    if (type) filter.company_type = type;

    const result = await paginate(CompanyModel, filter, req, {
      sort: { createdAt: -1, _id: -1 },
    });

    return success(res, result.items, "companies_list", 200, result.meta);
  } catch (error) {
    next(error);
  }
};

export const companyDetails = async (req, res, next) => {
  try {
    const { companyId } = req.params;
    if (!isValidObjectId(companyId)) return fail(res, "invalid_company_id", 400);

    const company = await CompanyModel.findOne({ _id: companyId, status: true, accepted: true });
    if (!company) return fail(res, "company_not_found", 404);

    const openJobs = await jobsModel
      .find({ company_id: companyId, status: true, is_accepted: true })
      .sort({ createdAt: -1 })
      .limit(10)
      .populate(publicJobPopulate);

    const stats = {
      open_jobs: await jobsModel.countDocuments({ company_id: companyId, status: true, is_accepted: true }),
      total_jobs: await jobsModel.countDocuments({ company_id: companyId, is_accepted: true }),
    };

    return success(res, { company, open_jobs: openJobs, stats }, "company_details");
  } catch (error) {
    next(error);
  }
};

export const companiesFromMyActivity = async (req, res, next) => {
  try {
    const employeeData = await getEmployeeUserIdOrFail(req, res);
    if (!employeeData) return;

    const companyIds = await getCompanyIdsFromEmployeeActivity(employeeData.userId);

    if (!companyIds.length) {
      return success(res, [], "companies_from_activity", 200, { page: 1, limit: 0, total: 0, pages: 0 });
    }

    const result = await paginate(
      CompanyModel,
      { _id: { $in: companyIds }, status: true, accepted: true },
      req
    );

    return success(res, result.items, "companies_from_activity", 200, result.meta);
  } catch (error) {
    next(error);
  }
};

export const companiesIAppliedTo = async (req, res, next) => {
  try {
    const employeeData = await getEmployeeUserIdOrFail(req, res);
    if (!employeeData) return;

    const applications = await UserApplyingJobModel.find({ user_id: employeeData.userId }).select("job_id");
    const jobIds = applications.map((x) => x.job_id).filter(Boolean);

    if (!jobIds.length) return success(res, [], "companies_i_applied_to");

    const jobs = await jobsModel.find({ _id: { $in: jobIds } }).select("company_id");
    const companyIds = [...new Set(jobs.map((j) => String(j.company_id)).filter(Boolean))];

    const result = await paginate(CompanyModel, { _id: { $in: companyIds } }, req);
    return success(res, result.items, "companies_i_applied_to", 200, result.meta);
  } catch (error) {
    next(error);
  }
};

export const companiesFromSavedJobs = async (req, res, next) => {
  try {
    const employeeData = await getEmployeeUserIdOrFail(req, res);
    if (!employeeData) return;

    const saved = await UserSavedJobModel.find({ user_id: employeeData.userId }).select("job_id");
    const jobIds = saved.map((x) => x.job_id).filter(Boolean);

    if (!jobIds.length) return success(res, [], "companies_from_saved_jobs");

    const jobs = await jobsModel.find({ _id: { $in: jobIds } }).select("company_id");
    const companyIds = [...new Set(jobs.map((j) => String(j.company_id)).filter(Boolean))];

    const result = await paginate(CompanyModel, { _id: { $in: companyIds } }, req);
    return success(res, result.items, "companies_from_saved_jobs", 200, result.meta);
  } catch (error) {
    next(error);
  }
};

export const companiesViewedByMe = async (req, res, next) => {
  try {
    const employeeData = await getEmployeeUserIdOrFail(req, res);
    if (!employeeData) return;

    const shown = await UserShowJobModel.find({ user_id: employeeData.userId }).select("job_id");
    const jobIds = shown.map((x) => x.job_id).filter(Boolean);

    if (!jobIds.length) return success(res, [], "companies_viewed_by_me");

    const jobs = await jobsModel.find({ _id: { $in: jobIds } }).select("company_id");
    const companyIds = [...new Set(jobs.map((j) => String(j.company_id)).filter(Boolean))];

    const result = await paginate(CompanyModel, { _id: { $in: companyIds } }, req);
    return success(res, result.items, "companies_viewed_by_me", 200, result.meta);
  } catch (error) {
    next(error);
  }
};

export default {
  browseCompanies,
  companyDetails,
  companiesFromMyActivity,
  companiesIAppliedTo,
  companiesFromSavedJobs,
  companiesViewedByMe,
};
