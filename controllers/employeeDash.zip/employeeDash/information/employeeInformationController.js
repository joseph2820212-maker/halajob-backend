import {
  getEmployeeOrFail,
  getEmployeePlain,
  normalizeArrayPayload,
  success,
  fail,
  calculateProfileCompletion,
  toObjectIdArray,
} from "../../../helper/employeeDash/employeeDashHelpers.js";
import { deleteImage, processUploadImage } from "../../../services/imageService.js";
import ReturnDashData from "../../../helper/ReturnDashData/index.js";
const ARRAY_FIELDS = new Set([
  "experience",
  "education",
  "skills",
  "languages",
  "licenses",
  "testimony",
  "links",
]);
const messages = {
  ar: {
    success: "تمت العملية بنجاح",
    created: "تمت الإضافة بنجاح",
    updated: "تم التعديل بنجاح",
    deleted: "تم الحذف بنجاح",
    invalid_section: "القسم غير صالح",
    item_not_found: "العنصر غير موجود",
  },
  en: {
    success: "success",
    created: "created successfully",
    updated: "updated successfully",
    deleted: "deleted successfully",
    invalid_section: "Invalid section",
    item_not_found: "Item not found",
  },
};

const getLang = (req) => {
  const lang =
    req.headers["x-lang"] ||
    req.headers["lang"] ||
    req.headers["language"] ||
    req.headers["accept-language"] ||
    "en";

  return String(lang).toLowerCase().startsWith("ar") ? "ar" : "en";
};

const msg = (req, key) => {
  const lang = getLang(req);
  return messages[lang]?.[key] || messages.en[key] || key;
};

const parseBool = (value) => {
  if (value === true || value === "true" || value === "1" || value === 1) {
    return true;
  }

  if (value === false || value === "false" || value === "0" || value === 0) {
    return false;
  }

  return value;
};

export const cleanSectionItem = (item = {}) => {
  const cleaned = { ...item };

  if (cleaned.evel !== undefined && cleaned.level === undefined) {
    cleaned.level = cleaned.evel;
    delete cleaned.evel;
  }

  for (const key of Object.keys(cleaned)) {
    if (cleaned[key] === "") {
      delete cleaned[key];
      continue;
    }

    if (key.startsWith("is_")) {
      cleaned[key] = parseBool(cleaned[key]);
    }
  }

  return cleaned;
};

const normalizeSectionItems = (body, section) => {
  const items = normalizeArrayPayload(body, section);
  return items.map(cleanSectionItem);
};

const paginateArray = (array = [], req) => {
  const {
    page = 1,
    limit = 10,
    search = "",
    sort = "createdAt",
  } = req.query;

  const pageNumber = Math.max(Number(page) || 1, 1);
  const limitNumber = Math.max(Number(limit) || 10, 1);

  let items = Array.isArray(array) ? [...array] : [];

  if (search) {
    const searchValue = String(search).toLowerCase();

    items = items.filter((item) =>
      JSON.stringify(item).toLowerCase().includes(searchValue)
    );
  }

  items.sort((a, b) => {
    const sortKey = String(sort).replace("-", "");
    const direction = String(sort).startsWith("-") ? -1 : 1;

    const aValue = a?.[sortKey];
    const bValue = b?.[sortKey];

    if (!aValue && !bValue) return 0;
    if (!aValue) return 1;
    if (!bValue) return -1;

    return String(aValue).localeCompare(String(bValue)) * direction;
  });

  const total = items.length;
  const skip = (pageNumber - 1) * limitNumber;

  return {
    data: items.slice(skip, skip + limitNumber),
    pagination: {
      page: pageNumber,
      limit: limitNumber,
      total,
      pages: Math.ceil(total / limitNumber),
    },
  };
};
const SINGLE_FIELDS = new Set([
  "about_me",
  "latest_work_experience",
  "work_location",
  "is_can_move",
  "is_free_for_work",
  "accepted",
  "status",
]);

export const getMyEmployeeProfile = async (req, res, next) => {
  try {
    const employee = await getEmployeeOrFail(req, res);
    if (!employee) return;

    return success(res, {
      employee,
      completion: calculateProfileCompletion(employee),
    });
  } catch (error) {
    next(error);
  }
};

export const getMyEmployeeCompletion = async (req, res, next) => {
  try {
    const employee = await getEmployeePlain(req, res);
    if (!employee) return;

    return success(res, calculateProfileCompletion(employee));
  } catch (error) {
    next(error);
  }
};

export const updateBasicEmployeeProfile = async (req, res, next) => {
  try {
    const employee = await getEmployeePlain(req, res);
    if (!employee) return;

    for (const field of SINGLE_FIELDS) {
      if (req.body[field] !== undefined) {
        employee[field] = req.body[field];
      }
    }

    await employee.save();
    return success(res, employee, "employee_profile_updated");
  } catch (error) {
    next(error);
  }
};

export const updateAboutMe = async (req, res, next) => {
  try {
    const employee = await getEmployeePlain(req, res);
    if (!employee) return;

    employee.about_me = req.body.about_me ?? "";
    await employee.save();

    return success(res, employee, "about_me_updated");
  } catch (error) {
    next(error);
  }
};

export const updateLatestWorkExperience = async (req, res, next) => {
  try {
    const employee = await getEmployeePlain(req, res);
    if (!employee) return;

    employee.latest_work_experience = {
      ...(employee.latest_work_experience?.toObject?.() || employee.latest_work_experience || {}),
      ...req.body,
    };

    await employee.save();
    return success(res, employee, "latest_work_experience_updated");
  } catch (error) {
    next(error);
  }
};

export const updateWorkPreferences = async (req, res, next) => {
  try {
    const employee = await getEmployeePlain(req, res);
    if (!employee) return;

    const { work_location, is_can_move, is_free_for_work } = req.body;

    if (work_location !== undefined) employee.work_location = work_location;
    if (typeof is_can_move === "boolean") employee.is_can_move = is_can_move;
    if (typeof is_free_for_work === "boolean") employee.is_free_for_work = is_free_for_work;

    await employee.save();
    return success(res, employee, "work_preferences_updated");
  } catch (error) {
    next(error);
  }
};

export const replaceSection = async (req, res, next) => {
  try {
    const { section } = req.params;

    if (!ARRAY_FIELDS.has(section) && !SINGLE_FIELDS.has(section)) {
      return fail(res, "invalid_employee_section", 400);
    }

    const employee = await getEmployeePlain(req, res);
    if (!employee) return;

    if (ARRAY_FIELDS.has(section)) {
      employee[section] = normalizeArrayPayload(req.body, section);
    } else {
      employee[section] =
        req.body?.[section] !== undefined
          ? req.body[section]
          : req.body;
    }

    await employee.save();

    return success(res, employee, `${section}_replaced`);
  } catch (error) {
    next(error);
  }
};

export const addSectionItems = async (req, res) => {
  try {
    const { section } = req.params;

    if (!ARRAY_FIELDS.has(section)) {
      return ReturnDashData.createError({
        res,
        message: msg(req, "invalid_section"),
      });
    }

    const employee = await getEmployeePlain(req, res);
    if (!employee) return;

    console.log("BODY:", req.body);

    const items = normalizeSectionItems(req.body, section);

    console.log("ITEMS:", items);

    employee[section].push(...items);

    await employee.save();

    const addedItems = employee[section].slice(-items.length);

    return ReturnDashData.createData({
      res,
      data: addedItems,
      other: {
        message: msg(req, "created"),
        section,
      },
    });
  } catch (error) {
    return ReturnDashData.createError({
      res,
      message: error.message || "Create failed",
    });
  }
};

export const updateSectionItem = async (req, res, next) => {
  try {
    const { section, itemId } = req.params;

    if (!ARRAY_FIELDS.has(section)) {
      return fail(res, "invalid_employee_section", 400);
    }

    const employee = await getEmployeePlain(req, res);
    if (!employee) return;

    const item = employee[section].id?.(itemId);
    if (!item) return fail(res, "employee_section_item_not_found", 404);

    item.set(req.body);

    await employee.save();
    return success(res, employee, `${section}_item_updated`);
  } catch (error) {
    next(error);
  }
};

export const deleteSectionItem = async (req, res, next) => {
  try {
    const { section, itemId } = req.params;

    if (!ARRAY_FIELDS.has(section)) {
      return fail(res, "invalid_employee_section", 400);
    }

    const employee = await getEmployeePlain(req, res);
    if (!employee) return;

    const item = employee[section].id?.(itemId);
    if (!item) return fail(res, "employee_section_item_not_found", 404);

    employee[section].pull({ _id: itemId });
    await employee.save();

    await employee.save();
    return success(res, employee, `${section}_item_deleted`);
  } catch (error) {
    console.log('====================================');
    console.log(error);
    console.log('====================================');
    next(error);
  }
};

export const replaceJobNames = async (req, res, next) => {
  try {
    const employee = await getEmployeePlain(req, res);
    if (!employee) return;

    const jobNames = normalizeArrayPayload(req.body, "job_names")
      .map((item) => String(item || "").trim())
      .filter(Boolean);

    employee.job_names = [...new Set(jobNames)];

    await employee.save();
    return success(res, employee, "job_names_replaced");
  } catch (error) {
    next(error);
  }
};

export const replaceJobTypes = async (req, res, next) => {
  try {
    const employee = await getEmployeePlain(req, res);
    if (!employee) return;

    const raw = normalizeArrayPayload(req.body, "job_types");
    employee.job_types = toObjectIdArray(raw);

    await employee.save();
    return success(res, employee, "job_types_replaced");
  } catch (error) {
    next(error);
  }
};

export const replaceMinSalary = async (req, res, next) => {
  try {
    const employee = await getEmployeePlain(req, res);
    if (!employee) return;

    employee.min_salary = normalizeArrayPayload(req.body, "min_salary");

    await employee.save();
    return success(res, employee, "min_salary_replaced");
  } catch (error) {
    next(error);
  }
};
export const getMyBasicProfile = async (req, res, next) => {
  try {
    const employee = await getEmployeePlain(req, res);
    if (!employee) return;

    await employee.populate("user_id", "-password -passcode -another_device_code -pending_device -device");

    return success(res, {
      user: {
        id: employee.user_id?._id,
        first_name: employee.user_id?.first_name,
        mid_name: employee.user_id?.mid_name,
        last_name: employee.user_id?.last_name,
        email: employee.user_id?.email,
        phone_code: employee.user_id?.phone_code,
        phone: employee.user_id?.phone_national,
        gender: employee.user_id?.gender,
        image: employee.user_id?.image,
        status: employee.user_id?.status,
      },
    });
  } catch (error) {
    next(error);
  }
};
export const updateMyBasicProfile = async (req, res, next) => {
  try {
    const employee = await getEmployeePlain(req, res);
    if (!employee) return;

    await employee.populate("user_id");

    const user = employee.user_id;
    if (!user) return fail(res, "user_not_found", 404);

    const {
      first_name,
      mid_name,
      last_name,
      phone,
      phone_code,
      gender,
    } = req.body;

    if (first_name !== undefined) user.first_name = first_name;
    if (mid_name !== undefined) user.mid_name = mid_name;
    if (last_name !== undefined) user.last_name = last_name;

    // حسب بياناتك أنت تعرض phone من phone_national
    if (phone !== undefined) user.phone_national = phone;
    if (phone_code !== undefined) user.phone_code = phone_code;

    if (gender !== undefined) user.gender = gender;

    const file = req.file || req.files?.image?.[0];

    if (file) {
      const oldImage = user.image;

      const uploaded = await processUploadImage(file, {
        targetDir: "employee",
        webpQuality: 82,
      });

      user.image = uploaded;

      if (oldImage) {
        await deleteImage(oldImage);
      }
    }

    await user.save();

    return success(
      res,
      {
        user: {
          id: user._id,
          first_name: user.first_name,
          mid_name: user.mid_name,
          last_name: user.last_name,
          email: user.email,
          phone_code: user.phone_code,
          phone: user.phone_national,
          gender: user.gender,
          image: user.image,
          status: user.status,
        },
      },
      "basic_profile_updated"
    );
  } catch (error) {
    next(error);
  }
};
export const getMySection = async (req, res, next) => {
  try {
    const { section } = req.params;

    if (!ARRAY_FIELDS.has(section) && !SINGLE_FIELDS.has(section)) {
      return ReturnDashData.getError({
        res,
        message: msg(req, "invalid_section"),
      });
    }

    const employee = await getEmployeePlain(req, res);
    if (!employee) return;

    if (ARRAY_FIELDS.has(section)) {
      const result = paginateArray(employee[section] || [], req);

      return ReturnDashData.getData({
        res,
        data: result.data,
        other: {
          section,
          pagination: result.pagination,
        },
      });
    }

    return ReturnDashData.getData({
      res,
      data: employee[section],
      other: {
        section,
      },
    });
  } catch (error) {
    return ReturnDashData.getError({
      res,
      message: error.message || "Get failed",
    });
  }
};
export default {
  getMyEmployeeProfile,
  getMyEmployeeCompletion,
  updateBasicEmployeeProfile,
  updateAboutMe,
  updateLatestWorkExperience,
  updateWorkPreferences,
  replaceSection,
  addSectionItems,
  updateSectionItem,
  deleteSectionItem,
  replaceJobNames,
  replaceJobTypes,
  replaceMinSalary,
  getMyBasicProfile,
  updateMyBasicProfile,
  getMySection
};
